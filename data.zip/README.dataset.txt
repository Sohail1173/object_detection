# gesture_detect > 2024-01-08 8:17pm
https://universe.roboflow.com/cardetect-qyykp/gesture_detect-4b22m

Provided by a Roboflow user
License: MIT

